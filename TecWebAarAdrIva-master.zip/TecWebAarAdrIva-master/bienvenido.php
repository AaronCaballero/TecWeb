<html>
<body>
<p>Inicio</p>
<?php 
$nombre = "Ana";
print(" <P>Hola, $nombre</P>"); 
 ?>
<p>Fin</p>
</body>
</html>